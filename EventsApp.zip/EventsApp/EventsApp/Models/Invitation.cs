using System.ComponentModel.DataAnnotations;

namespace EventsApp.Models
{
    public enum InvitationStatus
    {
        NotSent,
        Sent,
        Accepted,
        Declined
    }

    public class Invitation
    {
        public int Id { get; set; }

        [Required]
        public string GuestName { get; set; } = string.Empty;

        [Required]
        [EmailAddress]
        public string GuestEmail { get; set; } = string.Empty;

        public InvitationStatus Status { get; set; } = InvitationStatus.NotSent;

        public DateTime? SentAt { get; set; }
        public DateTime? RespondedAt { get; set; }

        public int PartyId { get; set; }
        public Party? Party { get; set; }
    }
}