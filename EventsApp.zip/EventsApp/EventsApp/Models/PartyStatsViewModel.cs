namespace EventsApp.Models
{
    public class PartyStatsViewModel
    {
        public Party Party { get; set; }

        public int Sent { get; set; }
        public int Accepted { get; set; }
        public int Declined { get; set; }
        public int NotSent { get; set; }
    }
}