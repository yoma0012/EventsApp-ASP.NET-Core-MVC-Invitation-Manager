using System.ComponentModel.DataAnnotations;

namespace EventsApp.Models
{
    public class Party
    {
        public int Id { get; set; }

        [Required]
        public string Description { get; set; } = string.Empty;

        [Required]
        public DateTime EventDate { get; set; }

        public string? Location { get; set; }

        public string? OwnerId { get; set; }

        public bool IsDeleted { get; set; }
        public DateTime? DeletedAt { get; set; }

        public List<Invitation> Invitations { get; set; } = new();
    }
}