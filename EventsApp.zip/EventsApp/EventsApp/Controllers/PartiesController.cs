using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EventsApp.Data;
using EventsApp.Models;

namespace EventsApp.Controllers
{
    [Authorize]
    public class PartiesController : Controller
    {
        private readonly ApplicationDbContext _context;

        public PartiesController(ApplicationDbContext context)
        {
            _context = context;
        }

        [AllowAnonymous]
        public async Task<IActionResult> Index()
        {
            var parties = await _context.Parties
                .Where(p => !p.IsDeleted)
                .OrderBy(p => p.EventDate)
                .ToListAsync();

            return View(parties);
        }

        [AllowAnonymous]
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
                return NotFound();

            var party = await _context.Parties
                .Include(p => p.Invitations)
                .FirstOrDefaultAsync(p => p.Id == id && !p.IsDeleted);

            if (party == null)
                return NotFound();

            var stats = new PartyStatsViewModel
            {
                Party = party,
                Sent = party.Invitations.Count(i => i.Status == InvitationStatus.Sent),
                Accepted = party.Invitations.Count(i => i.Status == InvitationStatus.Accepted),
                Declined = party.Invitations.Count(i => i.Status == InvitationStatus.Declined),
                NotSent = party.Invitations.Count(i => i.Status == InvitationStatus.NotSent)
            };

            return View(stats);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Party party)
        {
            if (!ModelState.IsValid)
                return View(party);

            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            party.OwnerId = userId;

            _context.Parties.Add(party);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
                return NotFound();

            var party = await _context.Parties.FindAsync(id);
            if (party == null || party.IsDeleted)
                return NotFound();

            if (!IsOwnerOrAdmin(party))
                return Forbid();

            return View(party);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Party party)
        {
            if (id != party.Id)
                return NotFound();

            if (!ModelState.IsValid)
                return View(party);

            var existing = await _context.Parties.FindAsync(id);
            if (existing == null || existing.IsDeleted)
                return NotFound();

            if (!IsOwnerOrAdmin(existing))
                return Forbid();

            existing.Description = party.Description;
            existing.EventDate = party.EventDate;
            existing.Location = party.Location;

            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }

        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
                return NotFound();

            var party = await _context.Parties
                .FirstOrDefaultAsync(p => p.Id == id && !p.IsDeleted);

            if (party == null)
                return NotFound();

            return View(party);
        }

        [Authorize(Roles = "Admin")]
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var party = await _context.Parties.FindAsync(id);
            if (party == null)
                return NotFound();

            party.IsDeleted = true;
            party.DeletedAt = DateTime.UtcNow;

            await _context.SaveChangesAsync();

            TempData["UndoPartyId"] = party.Id;
            TempData["Message"] = "Party deleted. You can undo this action.";

            return RedirectToAction(nameof(Index));
        }

        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> UndoDelete(int id)
        {
            var party = await _context.Parties.FindAsync(id);
            if (party == null)
                return NotFound();

            if (party.IsDeleted)
            {
                party.IsDeleted = false;
                party.DeletedAt = null;
                await _context.SaveChangesAsync();
            }

            return RedirectToAction(nameof(Index));
        }

        private bool IsOwnerOrAdmin(Party party)
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (userId == null)
                return false;

            if (party.OwnerId == userId)
                return true;

            if (User.IsInRole("Admin"))
                return true;

            return false;
        }
    }
}