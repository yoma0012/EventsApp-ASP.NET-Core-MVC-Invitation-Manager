using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using EventsApp.Data;
using EventsApp.Models;

namespace EventsApp.Controllers
{
    [Authorize]
    public class InvitationsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public InvitationsController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
                return NotFound();

            var invitation = await _context.Invitations
                .Include(i => i.Party)
                .FirstOrDefaultAsync(i => i.Id == id);

            if (invitation == null || invitation.Party == null || invitation.Party.IsDeleted)
                return NotFound();

            if (!CanManage(invitation.Party))
                return Forbid();

            return View(invitation);
        }

        public async Task<IActionResult> Create(int partyId)
        {
            var party = await _context.Parties.FindAsync(partyId);
            if (party == null || party.IsDeleted)
                return NotFound();

            if (!CanManage(party))
                return Forbid();

            var model = new Invitation
            {
                PartyId = partyId
            };

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(int partyId, Invitation invitation)
        {
            var party = await _context.Parties.FindAsync(partyId);
            if (party == null || party.IsDeleted)
                return NotFound();

            if (!CanManage(party))
                return Forbid();

            if (!ModelState.IsValid)
                return View(invitation);

            invitation.PartyId = partyId;
            invitation.Status = InvitationStatus.NotSent;

            _context.Invitations.Add(invitation);
            await _context.SaveChangesAsync();

            return RedirectToAction("Details", "Parties", new { id = partyId });
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
                return NotFound();

            var invitation = await _context.Invitations
                .Include(i => i.Party)
                .FirstOrDefaultAsync(i => i.Id == id);

            if (invitation == null || invitation.Party == null || invitation.Party.IsDeleted)
                return NotFound();

            if (!CanManage(invitation.Party))
                return Forbid();

            return View(invitation);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Invitation model)
        {
            if (id != model.Id)
                return NotFound();

            var invitation = await _context.Invitations
                .Include(i => i.Party)
                .FirstOrDefaultAsync(i => i.Id == id);

            if (invitation == null || invitation.Party == null || invitation.Party.IsDeleted)
                return NotFound();

            if (!CanManage(invitation.Party))
                return Forbid();

            if (!ModelState.IsValid)
                return View(model);

            invitation.GuestName = model.GuestName;
            invitation.GuestEmail = model.GuestEmail;

            await _context.SaveChangesAsync();

            return RedirectToAction("Details", "Parties", new { id = invitation.PartyId });
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
                return NotFound();

            var invitation = await _context.Invitations
                .Include(i => i.Party)
                .FirstOrDefaultAsync(i => i.Id == id);

            if (invitation == null || invitation.Party == null || invitation.Party.IsDeleted)
                return NotFound();

            if (!CanManage(invitation.Party))
                return Forbid();

            return View(invitation);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var invitation = await _context.Invitations
                .Include(i => i.Party)
                .FirstOrDefaultAsync(i => i.Id == id);

            if (invitation == null || invitation.Party == null || invitation.Party.IsDeleted)
                return NotFound();

            if (!CanManage(invitation.Party))
                return Forbid();

            var partyId = invitation.PartyId;

            _context.Invitations.Remove(invitation);
            await _context.SaveChangesAsync();

            return RedirectToAction("Details", "Parties", new { id = partyId });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Send(int id)
        {
            var invitation = await _context.Invitations
                .Include(i => i.Party)
                .FirstOrDefaultAsync(i => i.Id == id);

            if (invitation == null || invitation.Party == null || invitation.Party.IsDeleted)
                return NotFound();

            if (!CanManage(invitation.Party))
                return Forbid();

            invitation.Status = InvitationStatus.Sent;
            invitation.SentAt = DateTime.UtcNow;

            await _context.SaveChangesAsync();

            return RedirectToAction("Details", "Parties", new { id = invitation.PartyId });
        }

        [HttpPost]
        [Authorize]
        public async Task<IActionResult> Respond(int id, string answer)
        {
            var invitation = await _context.Invitations.FindAsync(id);
            if (invitation == null)
                return NotFound();

            if (answer == "yes")
                invitation.Status = InvitationStatus.Accepted;
            else
                invitation.Status = InvitationStatus.Declined;

            invitation.RespondedAt = DateTime.UtcNow;

            await _context.SaveChangesAsync();

            return RedirectToAction("Index", "Home");
        }

        private bool CanManage(Party party)
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (userId == null)
                return false;

            if (party.OwnerId == userId)
                return true;

            if (User.IsInRole("Admin"))
                return true;

            return false;
        }
    }
}